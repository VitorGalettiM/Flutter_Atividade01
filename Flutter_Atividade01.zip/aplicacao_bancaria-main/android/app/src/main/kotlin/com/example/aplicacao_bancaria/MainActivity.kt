package com.example.aplicacao_bancaria

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
